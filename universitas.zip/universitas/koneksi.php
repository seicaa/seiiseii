<?php

$koneksi = mysqli_connect('localhost','root','','db_universitass') or die ('Koneksi Gagal');

?>