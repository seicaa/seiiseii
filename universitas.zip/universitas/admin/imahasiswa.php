<?php
$nama = $_POST['nama_mahasiswa'];
$npm = $_POST['npm'];
$email = $_POST['email'];
$usia = $_POST['usia'];
$kode = $_POST['kode_prodi'];

include "../koneksi.php";

$query = "INSERT INTO mahasiswa values (null,'$nama','$npm','$email','$usia','$kode')";
$data = mysqli_query($koneksi,$query);

header("location:index.php");
?>