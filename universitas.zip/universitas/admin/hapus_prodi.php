<?php
include '../koneksi.php';

$kode = $_GET['kode_prodi'];

$query = "DELETE FROM prodi WHERE kode_prodi ='$kode'";
$data = mysqli_query($koneksi,$query);

header("location:prodi.php");
?>