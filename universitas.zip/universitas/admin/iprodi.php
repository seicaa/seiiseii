<?php
include "../koneksi.php";

$prodi= $_POST['kode_prodi'];
$nama_prodi = $_POST['nama_prodi'];
$data = "INSERT INTO `prodi`(`kode_prodi`, `nama_prodi`) VALUES ('$prodi', '$nama_prodi')";

if($koneksi->query($data)){
header("location: prodi.php");
}else{
header("location: tprodi.php");
}

?>