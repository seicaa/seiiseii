<?php
include '../koneksi.php';

$id_mahasiswa = $_GET['id_mahasiswa'];


$query = "DELETE FROM mahasiswa WHERE id_mahasiswa ='$id_mahasiswa'";
$data = mysqli_query($koneksi,$query);

header("location:index.php");
?>