
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa</title>
    <?php
    include 'link.php';
    ?>
</head>
<body>
<?php
include 'nav.php';
include '../koneksi.php';
?>
<br><br>
<div class="container">
<a class="btn btn-primary" href="tprodi.php">Tambah</a>
<hr style="color: black;">
<table class="mt-3 table table-striped  table-bordered">
    <tr class="fw-bold text-center">
        <th>Kode Prodi</th>
        <th>Nama Prodi</th>
        <th>Aksi</th>
    </tr>
<tbody>
      <?php
      $query = "SELECT * FROM prodi";
      $data = mysqli_query($koneksi,$query);
      while($row = mysqli_fetch_assoc($data)){
      ?>
      <tr align="center">
        <td><?= $row['kode_prodi']?></td>
        <td><?= $row['nama_prodi']?></td>
        <td>
        <a href="eprodi.php?kode_prodi=<?= $row['kode_prodi']?>" class="btn btn-warning">Edit</a>
        <a href="hapus_prodi.php?kode_prodi=<?= $row['kode_prodi']?>" class="btn btn-danger">Hapus</a>
      </td>
      </tr>
      <?php } ?>
</tbody>
</table>
</div>
</body>
</html>