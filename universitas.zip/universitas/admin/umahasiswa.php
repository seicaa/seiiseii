<?php 
include "../koneksi.php";
$id = $_POST['id_mahasiswa'];
$nama = $_POST['nama_mahasiswa'];
$npm = $_POST['npm'];
$email = $_POST['email'];
$usia = $_POST['usia'];
$kode = $_POST['kode_prodi'];

$data = mysqli_query($koneksi, "UPDATE mahasiswa set nama_mahasiswa = '$nama', npm = '$npm', email = '$email', usia = '$usia', kode_prodi = '$kode' WHERE id_mahasiswa = '$id'");
header("location:index.php");
?>