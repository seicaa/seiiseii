<?php 
include 'link.php';
 ?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 

include '../koneksi.php';
$query = mysqli_query($koneksi,"SELECT max(kode_prodi) as kodeTerbesar FROM prodi");
$data = mysqli_fetch_array($query);
$kodeprodi = $data['kodeTerbesar'];

$urutan =(int) substr($kodeprodi, 1, 2);

$urutan++;

$huruf = "A";
$kodeprodi = $huruf . sprintf("%02s", $urutan);

?>
	<div class="container card mt-5 mb-4 border-dark border-3">
    <div class="card-body">
        <div class="center-text">
<div class="container">
<a href="index.php" class="btn btn-primary"> KEMBALI </a>
<hr>
    <form action="iprodi.php" method="post">

<div class="form-group mb-2">
		<label>Kode Prodi</label>
		<input type="text" name="kode_prodi" class="form-control" value="<?= $kodeprodi?>" required>
	</div>
<div class="form-group mb-2">
		<label>Nama Prodi</label>
		<input type="text" name="nama_prodi" class="form-control" required>
	</div>
	<div style="float: right;">
		<button type="submit" class="btn btn-success"> SIMPAN </button>
		<button type="reset" class="btn btn-warning"> KOSONGKAN </button>
	</div>
    </form>
</body>
</html>