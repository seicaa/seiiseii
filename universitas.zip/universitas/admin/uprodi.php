<?php
include '../koneksi.php';
$kode_prodi = $_POST['kode_prodi'];
$nama_prodi = $_POST['nama_prodi'];

$query = "UPDATE prodi SET nama_prodi = '$nama_prodi' where kode_prodi = '$kode_prodi'";
$data = mysqli_query($koneksi,$query);

header("location:prodi.php");

?>