<?php
include 'link.php';
?>
<div class=" container card mt-5 mb-4 border-dark border-3">
    <div class="card-body">
        <div class="center-text">
<div class="container">
<a href="index.php" class="btn btn-primary"> KEMBALI </a>
<hr>

<?php
include '../koneksi.php';
$kode = $_GET['kode_prodi'];
$query= "SELECT * FROM prodi WHERE kode_prodi = '$kode'";
$data= mysqli_query($koneksi,$query);
$rawr = mysqli_fetch_array($data);
?>

<form method="post" action="uprodi.php">
<div class="form-group mb-2">
		<label>Kode Prodi</label>
		<input type="text" name="kode_prodi" value="<?=$rawr['kode_prodi']?>" class="form-control" readonly>
	</div>
	<div class="form-group mb-2">
		<label>Nama Prodi</label>
		<input type="text" name="nama_prodi" value="<?=$rawr['nama_prodi']?>" class="form-control" required>
	</div>
		<button type="submit" class="btn btn-success"> SIMPAN </button>
		<button type="reset" class="btn btn-warning"> KOSONGKAN </button>
	</div>
</form>
        </div>
    </div>
</div>