<?php
include 'link.php';
include '../koneksi.php';
?>

<div class="container card mt-5 mb-4 border-dark border-3">
    <div class="card-body">
        <div class="center-text">
<div class="container">
<a href="index.php" class="btn btn-primary"> KEMBALI </a>
<hr>
<form method="post" action="imahasiswa.php">
<div class="form-group mb-2">
		<label>Nama Mahasiswa</label>
		<input type="text" name="nama_mahasiswa" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>NPM</label>
		<input type="number" name="npm" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Email</label>
		<input type="email" name="email" class="form-control" required>
	</div>
    <div class="form-group mb-2">
		<label>Usia</label>
		<input type="number" name="usia" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Prodi</label>
		<select name="kode_prodi" id="submit" class="form-control bg-light text-dark">
          <?php foreach(mysqli_query($koneksi, 'SELECT * FROM prodi') as $prodi) { ?>
	         <option value="<?= $prodi['kode_prodi'] ?>"><?= $prodi['nama_prodi'] ?></option>
          <?php } ?>
        </select>
	</div>
	<div style="float: right;">
		<button type="submit" class="btn btn-success"> SIMPAN </button>
		<button type="reset" class="btn btn-warning"> KOSONGKAN </button>
	</div>
	</div>
</form>
        </div>
    </div>
</div>