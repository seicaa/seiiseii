<?php
include 'link.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa</title>
</head>
<body">
<?php
include 'nav.php';
include '../koneksi.php';
?>
<br><br>
<div class="container border border-white">
<a class="btn btn-primary" href="tmahasiswa.php">Tambah</a>

<table class="mt-3 table table-striped table-bordered border-black">
    <tr class="fw-bold text-center" align="center">
        <th>ID Mahasiswa</th>
        <th>Nama Mahasiswa</th>
        <th>NPM</th>
        <th>Email</th>
        <th>Usia</th>
        <th>Nama Program Studi</th>
        <th>Aksi</th>
    </tr>
<tbody>

      <?php
      $query = "SELECT * FROM mahasiswa left join prodi on mahasiswa.kode_prodi = prodi.kode_prodi";
      $data = mysqli_query($koneksi,$query);
      while($row = mysqli_fetch_assoc($data)){
        
      ?>
      <tr align="center">
        <td><?= $row['id_mahasiswa']?></td>
        <td><?= $row['nama_mahasiswa']?></td>
        <td><?= $row['npm']?></td>
        <td><?= $row['email']?></td>
        <td><?= $row['usia']?></td>
        <td><?= $row['nama_prodi']?></td>
        <td>
        <a href="emahasiswa.php?id_mahasiswa=<?= $row['id_mahasiswa']?>" class="btn btn-warning">Edit</a>
        <a href="hapus_mahasiswa.php?id_mahasiswa=<?= $row['id_mahasiswa']?>" class="btn btn-danger">Hapus</a>
        </td>
      </tr>
      <?php } ?>
</tbody>
</table>
<hr style="color: white;">
</div>
</body>
</html>
