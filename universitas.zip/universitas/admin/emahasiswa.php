<?php
include 'link.php';
?>
<div class=" container card mt-5 mb-4 border-dark border-3">
    <div class="card-body">
        <div class="center-text">
<div class="container">
<a href="index.php" class="btn btn-primary"> KEMBALI </a>
<hr>

<?php
include '../koneksi.php';
$id_mahasiswa = $_GET['id_mahasiswa'];
$query= "SELECT * FROM mahasiswa WHERE id_mahasiswa = '$id_mahasiswa'";
$data= mysqli_query($koneksi,$query);
$rawr = mysqli_fetch_array($data);
?>

<form method="post" action="umahasiswa.php">
<div class="form-group mb-2">
		<label>ID Mahasiswa</label>
		<input type="number" name="id_mahasiswa" value="<?=$rawr['id_mahasiswa']?>" class="form-control" readonly>
	</div>
	<div class="form-group mb-2">
		<label>Nama Mahasiswa</label>
		<input type="text" name="nama_mahasiswa" value="<?=$rawr['nama_mahasiswa']?>" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>NPM</label>
		<input type="number" name="npm" value="<?=$rawr['npm']?>" class="form-control" required>
	</div>
    <div class="form-group mb-2">
		<label>Email</label>
		<input type="text" name="email" value="<?=$rawr['email']?>" class="form-control" required>
	</div>
    <div class="form-group mb-2">
		<label>Usia</label>
		<input type="number" name="usia" value="<?=$rawr['usia']?>" class="form-control" required>
	</div>
	<div class="form-group mb-2">
		<label>Prodi</label>
		<select name="kode_prodi" id="" class="form-control bg-light text-dark">
          <?php foreach(mysqli_query($koneksi, 'select * from prodi') as $prodi) { ?>
	         <option value="<?= $prodi['kode_prodi'] ?>"><?= $prodi['nama_prodi'] ?></option>
          <?php } ?>
        </select>
	</div>
		<button type="submit" class="btn btn-success"> SIMPAN </button>
		<button type="reset" class="btn btn-warning"> KOSONGKAN </button>
	</div>
</form>
        </div>
    </div>
</div>