<?php
include 'link.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>universitas</title>
    <?php
    include 'link.php';
    ?>
</head>
<body>
<?php
include 'nav.php';
include 'koneksi.php';
?>
<br><br>
<h4 class="text-center container" style="color: black;">Silahkan Masukkan NPM Terlebih Dahulu</h4>
<br>

<div class="container mt-5">
        <table class="mt-3 table table-striped table-bordered ">
            <form action="" method="post">
                <input type="search" name="cari" placeholder="Masukkan NPM / Nama">
            </form>
            <thead>
                <tr align="center">
                    <th>Nama Mahasiswa</th>
                    <th>Npm</th>
                    <th>Email</th>
                    <th>Program Studi</th>
                </tr>
            </thead>
            <tbody>
            <?php 

if (isset($_POST['cari'])) {
    $c = $_POST['cari'];
    
    $q1 = mysqli_query($koneksi,'SELECT * FROM mahasiswa JOIN prodi ON mahasiswa.kode_prodi=prodi.kode_prodi');
    $w = mysqli_fetch_assoc($q1);
    
    $q = mysqli_query($koneksi,"SELECT * FROM mahasiswa where npm LIKE '%$c%' OR nama_mahasiswa = '$c'");
    $cacing = mysqli_num_rows($q);
    
    if ($cacing > 0) {
        while ($rawr = mysqli_fetch_assoc($q)) { ?>
            <tr align="center">
                <td><?= $rawr['nama_mahasiswa'] ?></td>
                <td><?= $rawr['npm'] ?></td>
                <td><?= $rawr['email'] ?></td>
                <td><?= $w['nama_prodi'] ?></td>
            </tr>
        <?php }
    } else { ?>
        <tr>
            <td colspan="4">Data tidak ada</td>
        </tr>
    <?php }
}
?>

            </tbody>
        </table>
    </div>

    <?php ?>


</body>
</html>
